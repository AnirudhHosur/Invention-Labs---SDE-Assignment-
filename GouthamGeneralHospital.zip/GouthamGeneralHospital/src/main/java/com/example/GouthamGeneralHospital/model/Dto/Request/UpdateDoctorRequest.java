package com.example.GouthamGeneralHospital.model.Dto.Request;

import com.example.GouthamGeneralHospital.model.Enum.DaysOfTheWeek;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateDoctorRequest {
    private String doctorId;
    private List<DaysOfTheWeek> daysOfTheWeek;
    private int maxNoOfAppointmentsPerDay;
}
