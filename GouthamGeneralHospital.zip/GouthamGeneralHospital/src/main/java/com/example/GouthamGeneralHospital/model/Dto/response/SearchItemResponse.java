package com.example.GouthamGeneralHospital.model.Dto.response;

import com.example.GouthamGeneralHospital.model.Enum.SearchItem;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SearchItemResponse {
    private String id;
    private String firstName;
    private String lastName;
    private SearchItem userType;
}
