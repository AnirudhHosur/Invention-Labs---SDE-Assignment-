package com.example.GouthamGeneralHospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;


@SpringBootApplication(exclude={DataSourceAutoConfiguration.class})
public class GouthamGeneralHospitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(GouthamGeneralHospitalApplication.class, args);
	}

}
