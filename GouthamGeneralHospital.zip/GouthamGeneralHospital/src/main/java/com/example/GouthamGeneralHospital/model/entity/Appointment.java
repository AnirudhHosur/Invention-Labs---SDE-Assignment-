package com.example.GouthamGeneralHospital.model.entity;

import com.example.GouthamGeneralHospital.model.Enum.SeverityOfTheAppointment;
import com.example.GouthamGeneralHospital.model.Enum.Speciality;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;


@Document("appointment")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Appointment {
    @Id
    private String appointmentId;
    @Enumerated(EnumType.ORDINAL)
    private Speciality speciality;
    @Enumerated(EnumType.ORDINAL)
    private SeverityOfTheAppointment severityOfTheAppointment;
    @Indexed
    private String patientId;
    private String doctorId;
    private int slot;
}
