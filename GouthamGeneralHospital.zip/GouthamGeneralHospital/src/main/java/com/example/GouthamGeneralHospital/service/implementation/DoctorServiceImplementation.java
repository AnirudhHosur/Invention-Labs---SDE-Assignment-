package com.example.GouthamGeneralHospital.service.implementation;

import com.example.GouthamGeneralHospital.model.Dto.Request.CreateDoctorRequest;
import com.example.GouthamGeneralHospital.model.Dto.Request.UpdateDoctorRequest;
import com.example.GouthamGeneralHospital.model.Dto.response.DoctorResponse;
import com.example.GouthamGeneralHospital.model.entity.Doctor;
import com.example.GouthamGeneralHospital.repository.DoctorRepository;
import com.example.GouthamGeneralHospital.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import javax.print.Doc;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class DoctorServiceImplementation implements DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    // As the input here is a list, it can accommodate single or multiple entries
    @Override
    public Boolean createDoctor(List<CreateDoctorRequest> createDoctorRequests) {
        try {
            List<Doctor> doctors = new ArrayList<>();
            createDoctorRequests.forEach(createDoctorRequest -> {
                Doctor doctor = Doctor.builder()
                        .firstName(createDoctorRequest.getFirstName())
                        .lastName(createDoctorRequest.getLastName())
                        .phoneNumber(createDoctorRequest.getPhoneNumber())
                        .speciality(createDoctorRequest.getSpeciality())
                        .daysOfTheWeek(createDoctorRequest.getDaysOfTheWeek())
                        .maxNoOfAppointmentsPerDay(createDoctorRequest.getMaxNoOfAppointmentsPerDay())
                        .build();
                doctors.add(doctor);
            });
            doctors.forEach(doctor -> {
                doctorRepository.save(doctor);
            });
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    // The doctor can only update his flexibility for work in a week
    @Override
    public Boolean updateDoctor(UpdateDoctorRequest updateDoctorRequest) {
        try {
            Optional<Doctor> doctor = doctorRepository.findById(updateDoctorRequest.getDoctorId());
            if (!doctor.isPresent()) {
                return Boolean.FALSE;
            }
            doctor.get().setMaxNoOfAppointmentsPerDay(updateDoctorRequest.getMaxNoOfAppointmentsPerDay());
            doctor.get().setDaysOfTheWeek(updateDoctorRequest.getDaysOfTheWeek());
            doctorRepository.save(doctor.get());
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    @Override
    public DoctorResponse getDoctorDetails(String doctorId) {
        try {
            Optional<Doctor> doctor = doctorRepository.findById(doctorId);
            if (!doctor.isPresent()) {
                return null;
            }
            DoctorResponse doctorResponse = DoctorResponse.builder()
                    .doctorId(doctor.get().getDoctorId())
                    .firstName(doctor.get().getFirstName())
                    .lastName(doctor.get().getLastName())
                    .phoneNumber(doctor.get().getPhoneNumber())
                    .speciality(doctor.get().getSpeciality())
                    .daysOfTheWeek(doctor.get().getDaysOfTheWeek())
                    .maxNoOfAppointmentsPerDay(doctor.get().getMaxNoOfAppointmentsPerDay())
                    .build();
            return doctorResponse;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Boolean deleteDoctor(String doctorId) {
        try {
            doctorRepository.deleteById(doctorId);
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    @Override
    public List<DoctorResponse> getAllDoctors() {
        try {
            List<Doctor> doctors = doctorRepository.findAll();
            List<DoctorResponse> responses = new ArrayList<>();
            for (int i = 0; i < doctors.size(); i++) {
                DoctorResponse doctorResponse = DoctorResponse.builder()
                        .doctorId(doctors.get(i).getDoctorId())
                        .firstName(doctors.get(i).getFirstName())
                        .lastName(doctors.get(i).getLastName())
                        .phoneNumber(doctors.get(i).getPhoneNumber())
                        .speciality(doctors.get(i).getSpeciality())
                        .daysOfTheWeek(doctors.get(i).getDaysOfTheWeek())
                        .maxNoOfAppointmentsPerDay(doctors.get(i).getMaxNoOfAppointmentsPerDay())
                        .build();
                responses.add(doctorResponse);
            }
            return responses;
        } catch (Exception e) {
            return null;
        }
    }

}
