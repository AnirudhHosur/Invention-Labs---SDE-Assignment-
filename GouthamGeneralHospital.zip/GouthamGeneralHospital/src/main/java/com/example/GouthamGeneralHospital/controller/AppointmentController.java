package com.example.GouthamGeneralHospital.controller;

import com.example.GouthamGeneralHospital.model.Dto.Request.CreateAppointmentRequest;
import com.example.GouthamGeneralHospital.model.Dto.Request.UpdateAppointmentRequest;
import com.example.GouthamGeneralHospital.model.Dto.response.AppointmentResponse;
import com.example.GouthamGeneralHospital.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/appointment")
public class AppointmentController {

    @Autowired
    AppointmentService appointmentService;

    @PostMapping(value = "/createAppointment")
    Boolean saveAppointmentDetails(@RequestBody CreateAppointmentRequest createAppointmentRequest) {
        return appointmentService.createAppointment(createAppointmentRequest);
    }

    @PutMapping(value = "/updateAppointment")
    Boolean updateAppointmentDetails(@RequestBody UpdateAppointmentRequest updateAppointmentRequest) {
        return appointmentService.updateAppointment(updateAppointmentRequest);
    }

    @GetMapping(value = "/getAllAppointments")
    List<AppointmentResponse> getListOfAllUnbookedAppointments(){
        return appointmentService.getListOfUnbookedAppointments();
    }

    @DeleteMapping(value = "/deleteAppointmentById/{id}")
    Boolean deleteAppointment(@PathVariable String id) {
        return appointmentService.deleteAppointment(id);
    }
}
