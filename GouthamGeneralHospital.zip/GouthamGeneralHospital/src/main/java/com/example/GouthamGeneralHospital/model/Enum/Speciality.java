package com.example.GouthamGeneralHospital.model.Enum;

public enum Speciality {
    Pediatrics("Pediatrics"),
    Cardiology("Cardiology"),
    Ophthalmology("Ophthalmology"),
    Gynaecology("Gynaecology"),
    PhysicalTherapy("PhysicalTherapy"),
    GeneralTherapy("GeneralTherapy");

    private String title;

    Speciality(String title){
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
