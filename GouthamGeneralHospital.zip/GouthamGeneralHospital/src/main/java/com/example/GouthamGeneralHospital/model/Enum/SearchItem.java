package com.example.GouthamGeneralHospital.model.Enum;

// You can search for either a patient or doctor
public enum SearchItem {
    DOCTOR,
    PATIENT;
}
