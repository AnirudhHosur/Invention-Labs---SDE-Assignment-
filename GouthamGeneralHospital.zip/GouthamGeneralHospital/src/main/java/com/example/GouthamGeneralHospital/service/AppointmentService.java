package com.example.GouthamGeneralHospital.service;

import com.example.GouthamGeneralHospital.model.Dto.Request.CreateAppointmentRequest;
import com.example.GouthamGeneralHospital.model.Dto.Request.UpdateAppointmentRequest;
import com.example.GouthamGeneralHospital.model.Dto.response.AppointmentResponse;

import java.util.List;

public interface AppointmentService {
    Boolean createAppointment(CreateAppointmentRequest createAppointmentRequest);

    Boolean updateAppointment(UpdateAppointmentRequest updateAppointmentRequest);

    Boolean deleteAppointment(String appointmentId);

    List<AppointmentResponse> getListOfUnbookedAppointments();
}
