package com.example.GouthamGeneralHospital.model.Dto.response;

import com.example.GouthamGeneralHospital.model.Enum.DaysOfTheWeek;
import com.example.GouthamGeneralHospital.model.Enum.Speciality;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DoctorResponse {
    private String doctorId;
    private String firstName;
    private String lastName;
    private long phoneNumber;
    private Speciality speciality;
    private List<DaysOfTheWeek> daysOfTheWeek;
    private int maxNoOfAppointmentsPerDay;
}
