package com.example.GouthamGeneralHospital.model.entity;

import com.example.GouthamGeneralHospital.model.Enum.DaysOfTheWeek;
import com.example.GouthamGeneralHospital.model.Enum.Speciality;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.*;
import java.util.List;

@Document("doctor")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Doctor {
    @Id
    private String doctorId;
    @Indexed
    private String firstName;
    private String lastName;
    private long phoneNumber;

    @Enumerated(EnumType.ORDINAL)
    private Speciality speciality;

    @Enumerated(EnumType.ORDINAL)
    private List<DaysOfTheWeek> daysOfTheWeek;

    private int maxNoOfAppointmentsPerDay;
}

