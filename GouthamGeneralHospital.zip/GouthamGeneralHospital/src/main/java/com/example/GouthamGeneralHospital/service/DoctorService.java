package com.example.GouthamGeneralHospital.service;


import com.example.GouthamGeneralHospital.model.Dto.Request.CreateDoctorRequest;
import com.example.GouthamGeneralHospital.model.Dto.Request.UpdateDoctorRequest;
import com.example.GouthamGeneralHospital.model.Dto.response.DoctorResponse;

import java.util.List;

public interface DoctorService {
    Boolean createDoctor(List<CreateDoctorRequest> createDoctorRequests);

    Boolean updateDoctor(UpdateDoctorRequest updateDoctorRequest);

    DoctorResponse getDoctorDetails(String doctorId);

    Boolean deleteDoctor(String doctorId);

    List<DoctorResponse> getAllDoctors();
}

