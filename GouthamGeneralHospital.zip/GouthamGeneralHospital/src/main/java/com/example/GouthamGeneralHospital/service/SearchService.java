package com.example.GouthamGeneralHospital.service;

import com.example.GouthamGeneralHospital.model.Dto.response.SearchItemResponse;
import com.example.GouthamGeneralHospital.model.Enum.SearchItem;

import java.util.List;

public interface SearchService {
    List<SearchItemResponse> search(SearchItem searchItem, String searchQuery); //SearchItem --> patient or doctor
}
