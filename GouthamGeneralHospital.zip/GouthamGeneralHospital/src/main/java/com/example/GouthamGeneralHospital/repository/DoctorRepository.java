package com.example.GouthamGeneralHospital.repository;

import com.example.GouthamGeneralHospital.model.entity.Doctor;
import org.springframework.stereotype.Repository;

@Repository
public interface DoctorRepository extends org.springframework.data.mongodb.repository.MongoRepository<Doctor,String> {
}
