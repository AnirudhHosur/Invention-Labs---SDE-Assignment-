package com.example.GouthamGeneralHospital.repository;

import com.example.GouthamGeneralHospital.model.entity.Appointment;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface AppointmentRepository extends MongoRepository<Appointment, String> {
    List<Appointment> findBySlot(int slot); //To find the list of appointments which have not been booked
}
