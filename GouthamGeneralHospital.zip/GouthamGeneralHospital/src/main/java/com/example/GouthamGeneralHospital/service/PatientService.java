package com.example.GouthamGeneralHospital.service;

import com.example.GouthamGeneralHospital.model.Dto.Request.CreatePatientRequest;
import com.example.GouthamGeneralHospital.model.Dto.response.PatientResponse;

import java.util.List;


public interface PatientService {
    Boolean createPatient(List<CreatePatientRequest> createPatientRequests);

    PatientResponse getPatientDetailsById(String patientId);

    List<PatientResponse> getAllPatients();
}
