package com.example.GouthamGeneralHospital.controller;

import com.example.GouthamGeneralHospital.model.Dto.response.SearchItemResponse;
import com.example.GouthamGeneralHospital.model.Enum.SearchItem;
import com.example.GouthamGeneralHospital.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/search")
public class SearchController {

    @Autowired
    SearchService searchService;

    @GetMapping
    public List<SearchItemResponse> search(@RequestParam SearchItem searchItem, @RequestParam String searchQuery){
        return searchService.search(searchItem, searchQuery);
    }
}
