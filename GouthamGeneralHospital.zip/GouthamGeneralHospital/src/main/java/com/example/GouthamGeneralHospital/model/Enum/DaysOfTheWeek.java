package com.example.GouthamGeneralHospital.model.Enum;

public enum DaysOfTheWeek {
    MONDAY("MONDAY"),
    TUESDAY("TUESDAY"),
    WEDNESDAY("WEDNESDAY"),
    THURSDAY("THURSDAY"),
    FRIDAY("FRIDAY"),
    SATURDAY("SATURDAY"),
    SUNDAY("SUNDAY");

    private String title;

    DaysOfTheWeek(String title){
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
