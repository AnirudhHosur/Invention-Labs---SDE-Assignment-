package com.example.GouthamGeneralHospital.model.Dto.response;

import com.example.GouthamGeneralHospital.model.Enum.SeverityOfTheAppointment;
import com.example.GouthamGeneralHospital.model.Enum.Speciality;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AppointmentResponse {
    private String appointmentId;
    private Speciality speciality;
    private SeverityOfTheAppointment severityOfTheAppointment;
    private String patientId;
    private String doctorId;
    private int slot;
}
