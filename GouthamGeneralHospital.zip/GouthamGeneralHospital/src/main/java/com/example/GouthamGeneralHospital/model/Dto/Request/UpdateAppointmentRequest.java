package com.example.GouthamGeneralHospital.model.Dto.Request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateAppointmentRequest { //Updating an appointment will connect the patient with the doctor
    private String appointmentId;
    private String doctorId;
    private int slot;
}
