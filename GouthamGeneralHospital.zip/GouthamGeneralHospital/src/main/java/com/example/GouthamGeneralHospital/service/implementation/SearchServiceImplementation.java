package com.example.GouthamGeneralHospital.service.implementation;

import com.example.GouthamGeneralHospital.model.Dto.response.SearchItemResponse;
import com.example.GouthamGeneralHospital.model.Enum.SearchItem;
import com.example.GouthamGeneralHospital.model.entity.Doctor;
import com.example.GouthamGeneralHospital.model.entity.Patient;
import com.example.GouthamGeneralHospital.repository.DoctorRepository;
import com.example.GouthamGeneralHospital.repository.PatientRepository;
import com.example.GouthamGeneralHospital.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SearchServiceImplementation implements SearchService {

    @Autowired
    DoctorRepository doctorRepository;

    @Autowired
    PatientRepository patientRepository;

    @Override
    public List<SearchItemResponse> search(SearchItem searchItem, String searchQuery) {
        List<SearchItemResponse> searchItemResponses = new ArrayList<>();
        // You cannot search by ID
        // the entered searchQuery shall be checked with all doctor attributes
        if (searchItem.equals(SearchItem.DOCTOR)) {
            List<Doctor> doctors = doctorRepository.findAll().stream().filter(
                    doctor -> doctor.getFirstName().contains(searchQuery) ||
                            doctor.getLastName().contains(searchQuery) ||
                            String.valueOf(doctor.getPhoneNumber()).contains(searchQuery) ||
                            doctor.getSpeciality().getTitle().contains(searchQuery) ||
                            String.valueOf(doctor.getMaxNoOfAppointmentsPerDay()).contains(searchQuery) ||
                            doctor.getDaysOfTheWeek().toString().contains(searchQuery)).collect(Collectors.toList());

            for (int i = 0; i < doctors.size(); i++) {
                SearchItemResponse searchItemResponse = SearchItemResponse.builder()
                        .firstName(doctors.get(i).getFirstName())
                        .lastName(doctors.get(i).getLastName())
                        .id(doctors.get(i).getDoctorId())
                        .userType(SearchItem.DOCTOR).build();
                searchItemResponses.add(searchItemResponse);
            }

        } // the entered searchQuery shall be checked with all patient attributes
        else if (searchItem.equals(SearchItem.PATIENT)) {
            List<Patient> patients = patientRepository.findAll().stream().filter(
                    patient -> patient.getFirstName().contains(searchQuery) ||
                            patient.getLastName().contains(searchQuery) ||
                            String.valueOf(patient.getPhoneNumber()).contains(searchQuery)).collect(Collectors.toList());

            for (int i = 0; i < patients.size(); i++) {
                SearchItemResponse searchItemResponse = SearchItemResponse.builder()
                        .id(patients.get(i).getPatientId())
                        .firstName(patients.get(i).getFirstName())
                        .lastName(patients.get(i).getLastName())
                        .userType(SearchItem.PATIENT).build();

                searchItemResponses.add(searchItemResponse);
            }
        }
        return searchItemResponses;
    }
}
