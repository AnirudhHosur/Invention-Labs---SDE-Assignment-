package com.example.GouthamGeneralHospital.model.Dto.Request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreatePatientRequest {
    private String firstName;
    private String lastName;
    private int age;
    private long phoneNumber;
}
