package com.example.GouthamGeneralHospital.controller;

import com.example.GouthamGeneralHospital.model.Dto.Request.CreateDoctorRequest;
import com.example.GouthamGeneralHospital.model.Dto.Request.UpdateDoctorRequest;
import com.example.GouthamGeneralHospital.model.Dto.response.DoctorResponse;
import com.example.GouthamGeneralHospital.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/doctor")
public class DoctorController {

    @Autowired
    DoctorService doctorService;

    @PostMapping(value = "/createDoctor")
    Boolean saveDoctorDetails(@RequestBody List<CreateDoctorRequest> createDoctorRequests){
        return doctorService.createDoctor(createDoctorRequests);
    }

    @PutMapping(value = "/updateDoctor")
    Boolean updateDoctorDetails(@RequestBody UpdateDoctorRequest updateDoctorRequest){
        return doctorService.updateDoctor(updateDoctorRequest);
    }

    @GetMapping(value = "/getDoctorById/{doctorId}")
    DoctorResponse getDoctorDetailsById(@PathVariable String doctorId){
        return doctorService.getDoctorDetails(doctorId);
    }

    @GetMapping(value = "/getAllDoctors")
    List<DoctorResponse> getAllDoctors(){
        return doctorService.getAllDoctors();
    }

    @DeleteMapping(value = "/deleteDoctorById/{id}")
    Boolean deleteDoctorDetails(@PathVariable String id){
        return doctorService.deleteDoctor(id);
    }

}
