package com.example.GouthamGeneralHospital.model.Dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PatientResponse {
    private String patientId;
    private String firstName;
    private String lastName;
    private int age;
    private long phoneNumber;
}
