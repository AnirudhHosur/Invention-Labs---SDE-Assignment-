package com.example.GouthamGeneralHospital.model.Enum;

import lombok.Getter;

@Getter
public enum SeverityOfTheAppointment {
    low(1),
    medium(2),
    high(3),
    veryHigh(4),
    emergency(5);

    private final int id;

    SeverityOfTheAppointment(int id) {
        this.id = id;
    }
}
