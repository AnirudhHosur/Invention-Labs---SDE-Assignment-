package com.example.GouthamGeneralHospital.controller;

import com.example.GouthamGeneralHospital.model.Dto.Request.CreatePatientRequest;
import com.example.GouthamGeneralHospital.model.Dto.response.PatientResponse;
import com.example.GouthamGeneralHospital.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/patient")
public class PatientController {

    @Autowired
    PatientService patientService;

    @PostMapping(value = "/savePatientDetails")
    Boolean savePatientDetails(@RequestBody List<CreatePatientRequest> createPatientRequests) {
        return patientService.createPatient(createPatientRequests);
    }

    @GetMapping(value = "/getPatientById/{id}")
    PatientResponse getPatientById(@PathVariable String id) {
        return patientService.getPatientDetailsById(id);
    }

    @GetMapping(value = "/getAllPatientDetails")
    List<PatientResponse> getAll() {
        return patientService.getAllPatients();
    }
}
