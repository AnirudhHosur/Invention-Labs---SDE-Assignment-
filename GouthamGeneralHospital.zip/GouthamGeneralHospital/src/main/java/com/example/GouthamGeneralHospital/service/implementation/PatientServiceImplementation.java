package com.example.GouthamGeneralHospital.service.implementation;

import com.example.GouthamGeneralHospital.model.Dto.Request.CreatePatientRequest;
import com.example.GouthamGeneralHospital.model.Dto.response.PatientResponse;
import com.example.GouthamGeneralHospital.model.entity.Patient;
import com.example.GouthamGeneralHospital.repository.PatientRepository;
import com.example.GouthamGeneralHospital.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PatientServiceImplementation implements PatientService {

    @Autowired
    private PatientRepository patientRepository;

    // Single/Multiple patients can be entered
    @Override
    public Boolean createPatient(List<CreatePatientRequest> createPatientRequests) {
        try {
            List<Patient> patients = new ArrayList<>();
            createPatientRequests.forEach(createPatientRequest -> {
                Patient patient = Patient.builder()
                        .firstName(createPatientRequest.getFirstName())
                        .lastName(createPatientRequest.getLastName())
                        .phoneNumber(createPatientRequest.getPhoneNumber())
                        .age(createPatientRequest.getAge())
                        .build();
                patients.add(patient);
            });
            patients.forEach(patient -> {
                patientRepository.save(patient);
            });
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    @Override
    public PatientResponse getPatientDetailsById(String patientId) {
        try {
            Optional<Patient> patient = patientRepository.findById(patientId);
            if (!patient.isPresent()) {
                return null;
            }
            PatientResponse patientResponse = PatientResponse.builder()
                    .patientId(patient.get().getPatientId())
                    .firstName(patient.get().getFirstName())
                    .lastName(patient.get().getLastName())
                    .age(patient.get().getAge())
                    .phoneNumber(patient.get().getPhoneNumber())
                    .build();
            return patientResponse;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<PatientResponse> getAllPatients() {

        try {
            List<Patient> patients = patientRepository.findAll();
            List<PatientResponse> patientResponses = new ArrayList<>();
            for (int i = 0; i < patients.size(); i++) {
                PatientResponse patientResponse = PatientResponse.builder()
                        .patientId(patients.get(i).getPatientId())
                        .firstName(patients.get(i).getFirstName())
                        .lastName(patients.get(i).getLastName())
                        .age(patients.get(i).getAge())
                        .phoneNumber(patients.get(i).getPhoneNumber())
                        .build();
                patientResponses.add(patientResponse);
            }
            return patientResponses;
        } catch (Exception e) {
            return null;
        }
    }

}
