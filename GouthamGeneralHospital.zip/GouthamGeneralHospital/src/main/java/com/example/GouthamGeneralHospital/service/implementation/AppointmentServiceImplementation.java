package com.example.GouthamGeneralHospital.service.implementation;

import com.example.GouthamGeneralHospital.model.Dto.Request.CreateAppointmentRequest;
import com.example.GouthamGeneralHospital.model.Dto.Request.UpdateAppointmentRequest;
import com.example.GouthamGeneralHospital.model.Dto.response.AppointmentResponse;
import com.example.GouthamGeneralHospital.model.entity.Appointment;
import com.example.GouthamGeneralHospital.repository.AppointmentRepository;
import com.example.GouthamGeneralHospital.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AppointmentServiceImplementation implements AppointmentService {

    @Autowired
    AppointmentRepository appointmentRepository;

    @Override
    public Boolean createAppointment(CreateAppointmentRequest createAppointmentRequest) {
        try {
            Appointment appointment = Appointment.builder()
                    .severityOfTheAppointment(createAppointmentRequest.getSeverityOfTheAppointment())
                    .speciality(createAppointmentRequest.getSpeciality())
                    .patientId(createAppointmentRequest.getPatientId())
                    .build();
            appointmentRepository.save(appointment);
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    // Updating an appointment shall connect the patient with the doctor
    @Override
    public Boolean updateAppointment(UpdateAppointmentRequest updateAppointmentRequest) {
        try {
            Optional<Appointment> appointment = appointmentRepository.findById(updateAppointmentRequest.getAppointmentId());
            if (!appointment.isPresent()) {
                return Boolean.FALSE;
            }
            appointment.get().setDoctorId(updateAppointmentRequest.getDoctorId());
            appointment.get().setSlot(updateAppointmentRequest.getSlot());
            appointmentRepository.save(appointment.get());
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    @Override
    public Boolean deleteAppointment(String appointmentId) {
        try {
            appointmentRepository.deleteById(appointmentId);
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    // By default, if an appointment is not updated(i.e. connected with a doctor). Then the value of slot shall be 0.
    // Thus, signifying that the appointment has not been booked
    @Override
    public List<AppointmentResponse> getListOfUnbookedAppointments() {
        List<Appointment> appointments = appointmentRepository.findBySlot(0);
        List<AppointmentResponse> responses = new ArrayList<>();
        for (int i = 0; i < appointments.size(); i++) {
            AppointmentResponse appointmentResponse = AppointmentResponse.builder()
                    .appointmentId(appointments.get(i).getAppointmentId())
                    .patientId(appointments.get(i).getPatientId())
                    .severityOfTheAppointment(appointments.get(i).getSeverityOfTheAppointment())
                    .speciality(appointments.get(i).getSpeciality())
                    .build();
            responses.add(appointmentResponse);
        }
        return responses;
    }
}
