package com.example.GouthamGeneralHospital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GouthamGeneralHospitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
